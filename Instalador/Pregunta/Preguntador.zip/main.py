try:
    import os, random, clipboard, time

    clear = lambda: os.system('cls')
    clear()
    os.system('del "C:\Program Files\Joaquim Company\Preguntador\preguntes\.wget-hsts"')
    f = open ("C:\\Program Files\\Joaquim Company\\Preguntador\\preguntes\\"+random.choice(os.listdir(r"C:\Program Files\Joaquim Company\Preguntador\preguntes")),'r', encoding='utf-8')
    mucho_texto = f.read()
    f.close()

    [objectiu ,DEFINIR, TEMES, QUESTS] = mucho_texto.split("//*\\\\")
    objectiu = int(objectiu[:-1])
    DEFINIR = DEFINIR[1:-1].split("\n")
    TEMES = TEMES[1:-1].split("\n")
    QUESTS = QUESTS[1:].split("\n")
    QUEST = []
    malament = 0
    for i in range(len(QUESTS) // 4):
        QUEST.append([QUESTS[i*4+1], QUESTS[i*4+2], QUESTS[i*4+3].split("//")])
    correcte = 0
    while correcte < objectiu:
        print("CORRECTES = " + str(correcte) + "     INCORRECTES = " + str(malament) + "     OBJECTIU = " + str(objectiu + (malament // 5)))

        atzar = random.randint(0, len(QUEST)-1)
        tema = ""
        try:
            if(QUEST[atzar][0][:2] == "T:"):
                tema = TEMES[int(QUEST[atzar][0][2:])]
            else:
                tema = QUEST[atzar][0]
        except:
            pass
        
        pregunta = QUEST[atzar][1]

        try:
            if(pregunta[:2] == "D:"):
                pregunta = "Defineix " + DEFINIR[int(pregunta[2:])].upper() + ": "
        except:
            pass
        
        solucio = QUEST[atzar][2]
        print(tema)
        if (input(pregunta+"\n").lower() in solucio):
            correcte += 1
            print("Correcte")
            seguir = False
            input()
        else:
            print("Malament")
            malament += 1
            print(str(solucio)[2:-2])
            seguir = True
        while(seguir):
            clipboard.copy("TRAMPOOOOOOOOOOOOOOS")
            while input() != str(solucio)[2:-2]:
                clipboard.copy("TRAMPOOOOOOOOOOOOOOS")
                pass
            if(clipboard.paste() != "TRAMPOOOOOOOOOOOOOOS"):
                print("Ets un trampos de tifla")
                time.sleep(10)
                print("A mi trampes no")
            else:
                seguir = False
                
        clear()
    clipboard.copy("TRAMPOOOOOOOOOOOOOOS")
except:
    pass
os.system('"C:\\Program Files\\Joaquim Company\\Preguntador\\registre.vbs"')
